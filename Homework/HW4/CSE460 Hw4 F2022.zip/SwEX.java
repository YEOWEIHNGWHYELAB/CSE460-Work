/**
 * This class has the start, reset, and stop operations. 
 */
public class SwEX {

	/**
	 * Starts the stopwatch by using the Timer class.
	 */
	public boolean startTimer() {
		return false;
	}

	/**
	 * Resets the start time to zero by using the Timer class.
	 */
	public boolean resetTimer() {
		return false;
	}

	/**
	 * Stops incrementing time by using the Timer class.
	 */
	public boolean stopTimer() {
		return false;
	}

}
