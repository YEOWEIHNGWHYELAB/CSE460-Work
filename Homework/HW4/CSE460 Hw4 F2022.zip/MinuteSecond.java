/**
 * This class is for adding and storing the number of minutes and seconds.
 */
public class MinuteSecond {

	/**
	 * Holds the number of minutes
	 */
	private int minutes;

	/**
	 * Holds the number of seconds
	 */
	private int seconds;

	/**
	 * Increments the number of minutes by 1 every time is called.
	 */
	public boolean addMinute() {
		return false;
	}

	/**
	 * Increments the number of seconds by 1 every time it is called.
	 */
	public boolean addSecond() {
		return false;
	}

	/**
	 * Returns the number of minutes
	 */
	public int getMintues() {
		return 0;
	}

	/**
	 * Returns the number of seconds.
	 */
	public int getSeconds() {
		return 0;
	}

}
