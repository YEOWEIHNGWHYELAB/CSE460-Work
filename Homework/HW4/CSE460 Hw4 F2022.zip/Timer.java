/**
 * This class assumes the speed of time is for the planet Earth. Timer calculates the time according to the passage of time on Earth. 
 */
public class Timer {

	/**
	 * This variable keeps the total number of seconds since the stopwatch started.
	 */
	private int totalTimeElapsed = 0;

	/**
	 * Keeps tracks whether or not the stopwatch is activated
	 */
	private boolean isRunning;

	/**
	 * The counter holds the number of counts from 0, 1, 2, ..., 60.
	 */
	private int counter;

	/**
	 * The start time is assumed to be 0 when the stopwatch is started.
	 */
	private final int startTime = 0;

	private MinuteSecond minuteSecond;

	/**
	 * This operation assumes the passage of time. It calculates the time with respect to speed on EarthX and returns the time elapsed when it is invoked. The calculated time can be obtained at every time increment.
	 */
	public MinuteSecond getCalculatedTime() {
		return null;
	}

	/**
	 * This operation resets the counter to 0. Time increments every second.
	 */
	private boolean incrementTime(int tick) {
		return false;
	}

	/**
	 * Stops incrementing time.
	 */
	public boolean stopIncrementingTime() {
		return false;
	}

	/**
	 * Starts incrementing time.
	 */
	public boolean startIncrmentingTime() {
		return false;
	}

}
